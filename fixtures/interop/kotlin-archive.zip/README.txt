Encave backup

This archive holds your whole cellar, as it was when the backup was made:
- cellar.json: wines, bottles, racks, the Journal and settings. It is the backup
  itself: in Encave, choose Settings > Your data > Import… and pick this archive
  (or cellar.json alone, without the photos and documents).
- photos/ and documents/: the label photos and documents, under readable names.
- files.json: which file is which photo or document.
The archive is not encrypted: keep it somewhere safe.

Sauvegarde Encave

Cette archive contient toute votre cave, telle qu'elle était au moment de la sauvegarde :
- cellar.json : vins, bouteilles, casiers, le Journal et les réglages. C'est la
  sauvegarde elle-même : dans Encave, choisissez Réglages > Vos données > Importer…
  et prenez cette archive (ou cellar.json seul, sans les photos ni les documents).
- photos/ et documents/ : les photos d'étiquettes et les documents, sous des noms lisibles.
- files.json : quel fichier est quelle photo ou quel document.
L'archive n'est pas chiffrée : gardez-la en lieu sûr.
